package com.example.ex2.ApiException;

public class ApiException extends RuntimeException {
    public ApiException(String message) {
        super(message);
    }
}